# Change Log

## 0.2.0
- support for the profile bio
- renamed to "Letterboxd Text Formatter"
- new icon
- various small fixes

## 0.1.0
- implemented support for the undo stack. All changes can now be undone using Cmd+z (mac) or Ctrl+z (PC)
- limited the URL patterns on which the extension script loads