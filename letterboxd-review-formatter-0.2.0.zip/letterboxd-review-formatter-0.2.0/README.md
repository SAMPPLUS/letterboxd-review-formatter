## Shortcuts
- Bold: (Cmd/Ctrl) + b
- Italic: (Cmd/Ctrl) + i
- Hyperlink: (Cmd/Ctrl) + k
- Quote: (Cmd/Ctrl) + Shift + .